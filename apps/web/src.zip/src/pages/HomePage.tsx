import { PageTransition } from "@/components/common/PageTransition";
import { FeaturedWork } from "@/components/sections/FeaturedWork";
import { Hero } from "@/components/sections/Hero";
import { HomeCTA } from "@/components/sections/HomeCTA";
import { Impact } from "@/components/sections/Impact";
import { JourneyPreview } from "@/components/sections/JourneyPreview";
import { SaasAnalyticsSimulation } from "@/components/sections/SaasAnalyticsSimulation";
import { Workflow } from "@/components/sections/Workflow";

export function HomePage() {
  return (
    <PageTransition>
      <Hero />
      <Impact />
      <SaasAnalyticsSimulation />
      <FeaturedWork />
      <Workflow />
      <JourneyPreview />
      <HomeCTA />
    </PageTransition>
  );
}
